/**
 * 
 */
package cl.curso.java.logui_app;

/**
 * @author Jos� Navarro
 *
 */
public class ConexionException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4104567827772553683L;

	/**
	 * @param message
	 * @param cause
	 */
	public ConexionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public ConexionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
