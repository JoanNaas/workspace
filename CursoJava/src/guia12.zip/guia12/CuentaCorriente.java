/**
 * 
 */
package guia12;

/**
 * @author Jos� Navarro Astudillo
 *
 *
 */
public class CuentaCorriente {
	
	private int lineaDeCredito;

	/**
	 * @param lineaDeCredito
	 */
	public CuentaCorriente(int lineaDeCredito) {
		super();
		this.lineaDeCredito = lineaDeCredito;
	}

	/**
	 * @return the lineaDeCredito
	 */
	public int getLineaDeCredito() {
		return lineaDeCredito;
	}

	/**
	 * @param lineaDeCredito the lineaDeCredito to set
	 */
	public void setLineaDeCredito(int lineaDeCredito) {
		this.lineaDeCredito = lineaDeCredito;
	}
	
	public void girarDinero( int monto)
	{
		
	}

}
