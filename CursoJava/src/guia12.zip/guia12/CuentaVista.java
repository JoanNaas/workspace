/**
 * 
 */
package guia12;

/**
 * @author Jos� Navarro Astudillo
 *
 *
 */
public class CuentaVista {

	
	public void girarDinero( int monto)
	{
		
	}
}
