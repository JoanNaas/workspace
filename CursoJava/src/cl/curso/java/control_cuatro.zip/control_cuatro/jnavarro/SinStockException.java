/**
 * 
 */
package cl.curso.java.control_cuatro.jnavarro;

/**
 * @author Jos� Navarro
 *
 */
public class SinStockException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2457933265403630062L;

	/**
	 * @param message
	 * 
	 * Creando una excepcion para arrojar un mensaje
	 */
	public SinStockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
		

	}

	
	
	
	
	
}
