/**
 * 
 */
package guia11;

/**
 * @author Jos� Navarro
 *
 */
public class RutNoValidoException extends RuntimeException {
	
	public RutNoValidoException(String message)
	{
		super( message );
	}
	
	

}
