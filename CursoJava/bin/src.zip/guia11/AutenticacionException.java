/**
 * 
 */
package guia11;

/**
 * @author Jos� Navarro
 *
 */
public class AutenticacionException extends Throwable {

	public AutenticacionException(String message)
	{
		super( message );
	}

}
