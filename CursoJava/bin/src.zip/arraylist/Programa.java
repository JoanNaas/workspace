/**
 * 
 */
package arraylist;

/**
 * @author Jos� Navarro
 *
 */
public class Programa {
	
	Contacto jose = new Contacto("Jose", 12345678, "asdasdasd@gmail.com");
	
	Telefono lg = new Telefono(contactos);
	

}
